/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J06005;

/**
 *
 * @author DELL
 */
public class HoaDon {
    private String id;
    private KhachHang kh;
    private MatHang mh;
    private int soLuong;

    public HoaDon(String id, KhachHang kh, MatHang mh, int soLuong) {
        this.id = id;
        this.kh = kh;
        this.mh = mh;
        this.soLuong = soLuong;
    }
    
    public long loiNhuan(){
        return (long)soLuong * (mh.getGiaBan() - mh.getGiaMua());
    }
    
    public long thanhTien(){
        return (long)soLuong * (mh.getGiaBan());
    }
    
    public String toString(){
        return id + " " + kh.getName() + " " + kh.getAdd() + " " + mh.getName() + " " + soLuong
                + " " + thanhTien() + " " + loiNhuan(); 
    }
}
