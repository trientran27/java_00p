/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J06005;

/**
 *
 * @author DELL
 */
public class MatHang {
    private String id, name, donVi;
    private int giaMua, giaBan;

    public MatHang(String id, String name, String donVi, int giaMua, int giaBan) {
        this.id = id;
        this.name = name;
        this.donVi = donVi;
        this.giaMua = giaMua;
        this.giaBan = giaBan;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDonVi() {
        return donVi;
    }

    public int getGiaMua() {
        return giaMua;
    }

    public int getGiaBan() {
        return giaBan;
    }
    
    
}
