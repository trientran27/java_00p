/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J06005;

/**
 *
 * @author DELL
 */
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<KhachHang> list1 = new ArrayList<>();
        ArrayList<MatHang> list2 = new ArrayList<>();
        ArrayList<HoaDon> list3 = new ArrayList<>();
        int n = Integer.parseInt(sc.nextLine());
        for(int i = 0; i < n; i++){
            list1.add(new KhachHang("KH" + String.format("%03d", i + 1), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        }
        int m = Integer.parseInt(sc.nextLine());
        for(int i = 0; i < m; i++){
            list2.add(new MatHang("MH" + String.format("%03d", i + 1), sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine())));
        }
        int k = sc.nextInt();
        for(int i = 0; i < k; i++){
            String id_kh = sc.next();
            String id_mh = sc.next();
            int soLuong = sc.nextInt();
            KhachHang kh = null;
            MatHang mh = null;
            for(int j = 0; j < n; j++){
                if(id_kh.equals(list1.get(j).getId())){
                    kh = list1.get(j);
                    break;
                }
            }
            for(int j = 0; j < m; j++){
                if(id_mh.equals(list2.get(j).getId())){
                    mh = list2.get(j);
                    break;
                }
            }
            list3.add(new HoaDon("HD" + String.format("%03d", i + 1), kh, mh, soLuong));
        }
        Collections.sort(list3, new Comparator<HoaDon>(){
            public int compare(HoaDon o1, HoaDon o2){
                return (int)(o2.loiNhuan() - o1.loiNhuan());
            }
        });
        for(int i = 0; i < k; i++){
            System.out.println(list3.get(i));
        }
    }
}
