/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J06005;

/**
 *
 * @author DELL
 */
public class KhachHang {
    private String id, name, sex, birth, add;

    public KhachHang(String id, String name, String sex, String birth, String add) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.birth = birth;
        this.add = add;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }

    public String getBirth() {
        return birth;
    }

    public String getAdd() {
        return add;
    }
    
    
}
